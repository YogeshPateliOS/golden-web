$(document).ready(function () {
    $(window).scrollPress();
});
